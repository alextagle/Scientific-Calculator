﻿Imports System.Math
Public Class Form1
    Dim firstNum As Decimal = 0
    Dim Display As String
    Dim secondNum As Decimal
    Dim subtotNum As Decimal = 0
    Dim totalNum As Decimal = 0
    Dim Operations As Integer
    Dim opsFlag As Boolean = False
    Dim flag As Boolean = False
    Dim sign As String

    Private Sub oneBtn_Click(sender As Object, e As EventArgs) Handles oneBtn.Click


        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "1"
            opsFlag = True
        Else
            txtScreen.Text = 1
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 1
            flag = False
            opsFlag = True
        End If

    End Sub

    Private Sub twoBtn_Click(sender As Object, e As EventArgs) Handles twoBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "2"
            opsFlag = True
        Else
            txtScreen.Text = 2
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 2
            flag = False
            opsFlag = True
        End If
    End Sub

    Private Sub threeBtn_Click(sender As Object, e As EventArgs) Handles threeBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "3"
            opsFlag = True
        Else
            txtScreen.Text = 3
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 3
            flag = False
            opsFlag = True
        End If
    End Sub

    Private Sub fourBtn_Click(sender As Object, e As EventArgs) Handles fourBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "4"
            opsFlag = True
        Else
            txtScreen.Text = 4
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 4
            flag = False
            opsFlag = True
        End If
    End Sub

    Private Sub fiveBtn_Click(sender As Object, e As EventArgs) Handles fiveBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "5"
            opsFlag = True
        Else
            txtScreen.Text = 5
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 5
            flag = False
            opsFlag = True
        End If
    End Sub

    Private Sub sixBtn_Click(sender As Object, e As EventArgs) Handles sixBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "6"
            opsFlag = True
        Else
            txtScreen.Text = 6
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 6
            flag = False
            opsFlag = True
        End If


    End Sub

    Private Sub sevenBtn_Click(sender As Object, e As EventArgs) Handles sevenBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "7"
            opsFlag = True
        Else
            txtScreen.Text = 7
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 7
            flag = False
            opsFlag = True
        End If
    End Sub

    Private Sub eightBtn_Click(sender As Object, e As EventArgs) Handles eightBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "8"
            opsFlag = True
        Else
            txtScreen.Text = 8
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 8
            flag = False
            opsFlag = True
        End If
    End Sub

    Private Sub nineBtn_Click(sender As Object, e As EventArgs) Handles nineBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "9"
            opsFlag = True
        Else
            txtScreen.Text = 9
            opsFlag = True
        End If
        If (flag = True) Then
            txtScreen.Text = 9
            flag = False
            opsFlag = True
        End If
    End Sub

    Private Sub zeroBtn_Click(sender As Object, e As EventArgs) Handles zeroBtn.Click
        If (txtScreen.Text <> "0") Then
            txtScreen.Text += "0"
        End If
        If (flag = True) Then
            txtScreen.Text = 0
            flag = False
        End If
    End Sub

    Private Sub dotBtn_Click(sender As Object, e As EventArgs) Handles dotBtn.Click
        If Not (txtScreen.Text.Contains(".")) Then
            txtScreen.Text += "."
        End If
        If (flag = True) Then
            txtScreen.Text = "."
            flag = False
        End If

        'equalBtn.FlatAppearance.BorderSize = 0
    End Sub

    Private Sub plusBtn_Click(sender As Object, e As EventArgs) Handles plusBtn.Click


    End Sub

    Private Sub minusBtn_Click(sender As Object, e As EventArgs) Handles minusBtn.Click


    End Sub

    Private Sub mulBtn_Click(sender As Object, e As EventArgs) Handles mulBtn.Click

    End Sub

    Private Sub divBtn_Click(sender As Object, e As EventArgs) Handles divBtn.Click

    End Sub


    Private Sub delBtn_Click(sender As Object, e As EventArgs) Handles delBtn.Click
        If (txtScreen.Text.Length = 1) Then
            txtScreen.Text = "0"
        End If
        If (txtScreen.Text.Length > 1) Then
            txtScreen.Text = txtScreen.Text.Remove(txtScreen.Text.Length - 1, 1)

        End If
    End Sub

    Private Sub equalBtn_Click(sender As Object, e As EventArgs) Handles equalBtn.Click


    End Sub

    Private Sub clearBtn_Click(sender As Object, e As EventArgs) Handles clearBtn.Click
        txtScreen.Text = "0"
        txtScreen2.Text = ""
        firstNum = 0
        secondNum = 0
        subtotNum = 0
        flag = True
    End Sub

    Private Sub equalBlue(sender As Object, e As EventArgs) Handles equalBtn.MouseLeave
        equalBtn.BackColor = Color.FromArgb(154, 194, 219)
    End Sub



End Class
