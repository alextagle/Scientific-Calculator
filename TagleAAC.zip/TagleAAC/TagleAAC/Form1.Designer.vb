﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.equalBtn = New System.Windows.Forms.Button()
        Me.dotBtn = New System.Windows.Forms.Button()
        Me.zeroBtn = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.lnBtn = New System.Windows.Forms.Button()
        Me.logBtn = New System.Windows.Forms.Button()
        Me.oneBtn = New System.Windows.Forms.Button()
        Me.twoBtn = New System.Windows.Forms.Button()
        Me.threeBtn = New System.Windows.Forms.Button()
        Me.plusBtn = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.fourBtn = New System.Windows.Forms.Button()
        Me.fiveBtn = New System.Windows.Forms.Button()
        Me.sixBtn = New System.Windows.Forms.Button()
        Me.minusBtn = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.sevenBtn = New System.Windows.Forms.Button()
        Me.eightBtn = New System.Windows.Forms.Button()
        Me.nineBtn = New System.Windows.Forms.Button()
        Me.mulBtn = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.openparBtn = New System.Windows.Forms.Button()
        Me.closeparBtn = New System.Windows.Forms.Button()
        Me.factBtn = New System.Windows.Forms.Button()
        Me.divBtn = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.absBtn = New System.Windows.Forms.Button()
        Me.expBtn = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.clearBtn = New System.Windows.Forms.Button()
        Me.delBtn = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.MC = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.txtScreen = New System.Windows.Forms.TextBox()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.txtScreen2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'equalBtn
        '
        Me.equalBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(154, Byte), Integer), CType(CType(194, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.equalBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.equalBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.equalBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(142, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.equalBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.equalBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.equalBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.equalBtn.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.equalBtn.Location = New System.Drawing.Point(254, 458)
        Me.equalBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.equalBtn.Name = "equalBtn"
        Me.equalBtn.Size = New System.Drawing.Size(63, 40)
        Me.equalBtn.TabIndex = 0
        Me.equalBtn.Text = "="
        Me.equalBtn.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.equalBtn.UseVisualStyleBackColor = False
        '
        'dotBtn
        '
        Me.dotBtn.BackColor = System.Drawing.Color.White
        Me.dotBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.dotBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.dotBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.dotBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.dotBtn.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dotBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.dotBtn.Location = New System.Drawing.Point(191, 458)
        Me.dotBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.dotBtn.Name = "dotBtn"
        Me.dotBtn.Size = New System.Drawing.Size(63, 40)
        Me.dotBtn.TabIndex = 1
        Me.dotBtn.Text = "."
        Me.dotBtn.UseVisualStyleBackColor = False
        '
        'zeroBtn
        '
        Me.zeroBtn.BackColor = System.Drawing.Color.White
        Me.zeroBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.zeroBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.zeroBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.zeroBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.zeroBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.zeroBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.zeroBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.zeroBtn.Location = New System.Drawing.Point(128, 458)
        Me.zeroBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.zeroBtn.Name = "zeroBtn"
        Me.zeroBtn.Size = New System.Drawing.Size(63, 40)
        Me.zeroBtn.TabIndex = 2
        Me.zeroBtn.Text = "0"
        Me.zeroBtn.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.White
        Me.Button4.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Button4.Location = New System.Drawing.Point(65, 458)
        Me.Button4.Margin = New System.Windows.Forms.Padding(0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(63, 40)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "+/-"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'lnBtn
        '
        Me.lnBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.lnBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.lnBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.lnBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.lnBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.lnBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lnBtn.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lnBtn.Location = New System.Drawing.Point(2, 458)
        Me.lnBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.lnBtn.Name = "lnBtn"
        Me.lnBtn.Size = New System.Drawing.Size(63, 40)
        Me.lnBtn.TabIndex = 4
        Me.lnBtn.Text = "ln"
        Me.lnBtn.UseVisualStyleBackColor = False
        '
        'logBtn
        '
        Me.logBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.logBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.logBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.logBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.logBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.logBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.logBtn.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logBtn.Location = New System.Drawing.Point(2, 419)
        Me.logBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.logBtn.Name = "logBtn"
        Me.logBtn.Size = New System.Drawing.Size(63, 40)
        Me.logBtn.TabIndex = 9
        Me.logBtn.Text = "log"
        Me.logBtn.UseVisualStyleBackColor = False
        '
        'oneBtn
        '
        Me.oneBtn.BackColor = System.Drawing.Color.White
        Me.oneBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.oneBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.oneBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.oneBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.oneBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.oneBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.oneBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.oneBtn.Location = New System.Drawing.Point(65, 419)
        Me.oneBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.oneBtn.Name = "oneBtn"
        Me.oneBtn.Size = New System.Drawing.Size(63, 40)
        Me.oneBtn.TabIndex = 8
        Me.oneBtn.Text = "1"
        Me.oneBtn.UseVisualStyleBackColor = False
        '
        'twoBtn
        '
        Me.twoBtn.BackColor = System.Drawing.Color.White
        Me.twoBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.twoBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.twoBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.twoBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.twoBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.twoBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.twoBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.twoBtn.Location = New System.Drawing.Point(128, 419)
        Me.twoBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.twoBtn.Name = "twoBtn"
        Me.twoBtn.Size = New System.Drawing.Size(63, 40)
        Me.twoBtn.TabIndex = 7
        Me.twoBtn.Text = "2"
        Me.twoBtn.UseVisualStyleBackColor = False
        '
        'threeBtn
        '
        Me.threeBtn.BackColor = System.Drawing.Color.White
        Me.threeBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.threeBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.threeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.threeBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.threeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.threeBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.threeBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.threeBtn.Location = New System.Drawing.Point(191, 419)
        Me.threeBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.threeBtn.Name = "threeBtn"
        Me.threeBtn.Size = New System.Drawing.Size(63, 40)
        Me.threeBtn.TabIndex = 6
        Me.threeBtn.Text = "3"
        Me.threeBtn.UseVisualStyleBackColor = False
        '
        'plusBtn
        '
        Me.plusBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.plusBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.plusBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.plusBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.plusBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.plusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.plusBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.plusBtn.ForeColor = System.Drawing.Color.Gray
        Me.plusBtn.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.plusBtn.Location = New System.Drawing.Point(254, 419)
        Me.plusBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.plusBtn.Name = "plusBtn"
        Me.plusBtn.Size = New System.Drawing.Size(63, 40)
        Me.plusBtn.TabIndex = 5
        Me.plusBtn.Text = "+"
        Me.plusBtn.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button11.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button11.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(2, 380)
        Me.Button11.Margin = New System.Windows.Forms.Padding(0)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(63, 40)
        Me.Button11.TabIndex = 14
        Me.Button11.Text = "10²"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'fourBtn
        '
        Me.fourBtn.BackColor = System.Drawing.Color.White
        Me.fourBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.fourBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.fourBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.fourBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.fourBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.fourBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fourBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.fourBtn.Location = New System.Drawing.Point(65, 380)
        Me.fourBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.fourBtn.Name = "fourBtn"
        Me.fourBtn.Size = New System.Drawing.Size(63, 40)
        Me.fourBtn.TabIndex = 13
        Me.fourBtn.Text = "4"
        Me.fourBtn.UseVisualStyleBackColor = False
        '
        'fiveBtn
        '
        Me.fiveBtn.BackColor = System.Drawing.Color.White
        Me.fiveBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.fiveBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.fiveBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.fiveBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.fiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.fiveBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fiveBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.fiveBtn.Location = New System.Drawing.Point(128, 380)
        Me.fiveBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.fiveBtn.Name = "fiveBtn"
        Me.fiveBtn.Size = New System.Drawing.Size(63, 40)
        Me.fiveBtn.TabIndex = 12
        Me.fiveBtn.Text = "5"
        Me.fiveBtn.UseVisualStyleBackColor = False
        '
        'sixBtn
        '
        Me.sixBtn.BackColor = System.Drawing.Color.White
        Me.sixBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.sixBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.sixBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.sixBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.sixBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.sixBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sixBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.sixBtn.Location = New System.Drawing.Point(191, 380)
        Me.sixBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.sixBtn.Name = "sixBtn"
        Me.sixBtn.Size = New System.Drawing.Size(63, 40)
        Me.sixBtn.TabIndex = 11
        Me.sixBtn.Text = "6"
        Me.sixBtn.UseVisualStyleBackColor = False
        '
        'minusBtn
        '
        Me.minusBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.minusBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.minusBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.minusBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.minusBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.minusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.minusBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minusBtn.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.minusBtn.Location = New System.Drawing.Point(254, 380)
        Me.minusBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.minusBtn.Name = "minusBtn"
        Me.minusBtn.Size = New System.Drawing.Size(63, 40)
        Me.minusBtn.TabIndex = 10
        Me.minusBtn.Text = "—"
        Me.minusBtn.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button16.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button16.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button16.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.Location = New System.Drawing.Point(2, 341)
        Me.Button16.Margin = New System.Windows.Forms.Padding(0)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(63, 40)
        Me.Button16.TabIndex = 19
        Me.Button16.Text = "x^y"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'sevenBtn
        '
        Me.sevenBtn.BackColor = System.Drawing.Color.White
        Me.sevenBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.sevenBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.sevenBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.sevenBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.sevenBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.sevenBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sevenBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.sevenBtn.Location = New System.Drawing.Point(65, 341)
        Me.sevenBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.sevenBtn.Name = "sevenBtn"
        Me.sevenBtn.Size = New System.Drawing.Size(63, 40)
        Me.sevenBtn.TabIndex = 18
        Me.sevenBtn.Text = "7"
        Me.sevenBtn.UseVisualStyleBackColor = False
        '
        'eightBtn
        '
        Me.eightBtn.BackColor = System.Drawing.Color.White
        Me.eightBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.eightBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.eightBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.eightBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.eightBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.eightBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eightBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.eightBtn.Location = New System.Drawing.Point(128, 341)
        Me.eightBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.eightBtn.Name = "eightBtn"
        Me.eightBtn.Size = New System.Drawing.Size(63, 40)
        Me.eightBtn.TabIndex = 17
        Me.eightBtn.Text = "8"
        Me.eightBtn.UseVisualStyleBackColor = False
        '
        'nineBtn
        '
        Me.nineBtn.BackColor = System.Drawing.Color.White
        Me.nineBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.nineBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.nineBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.nineBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.nineBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.nineBtn.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nineBtn.ForeColor = System.Drawing.SystemColors.Desktop
        Me.nineBtn.Location = New System.Drawing.Point(191, 341)
        Me.nineBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.nineBtn.Name = "nineBtn"
        Me.nineBtn.Size = New System.Drawing.Size(63, 40)
        Me.nineBtn.TabIndex = 16
        Me.nineBtn.Text = "9"
        Me.nineBtn.UseVisualStyleBackColor = False
        '
        'mulBtn
        '
        Me.mulBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.mulBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.mulBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.mulBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.mulBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.mulBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.mulBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mulBtn.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.mulBtn.Location = New System.Drawing.Point(254, 341)
        Me.mulBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.mulBtn.Name = "mulBtn"
        Me.mulBtn.Size = New System.Drawing.Size(63, 40)
        Me.mulBtn.TabIndex = 15
        Me.mulBtn.Text = "×"
        Me.mulBtn.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button21.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button21.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Font = New System.Drawing.Font("Open Sans", 10.5!)
        Me.Button21.Location = New System.Drawing.Point(2, 302)
        Me.Button21.Margin = New System.Windows.Forms.Padding(0)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(63, 40)
        Me.Button21.TabIndex = 24
        Me.Button21.Text = "x³"
        Me.Button21.UseVisualStyleBackColor = False
        '
        'openparBtn
        '
        Me.openparBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.openparBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.openparBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.openparBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.openparBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.openparBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.openparBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.openparBtn.Location = New System.Drawing.Point(65, 302)
        Me.openparBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.openparBtn.Name = "openparBtn"
        Me.openparBtn.Size = New System.Drawing.Size(63, 40)
        Me.openparBtn.TabIndex = 23
        Me.openparBtn.Text = "("
        Me.openparBtn.UseVisualStyleBackColor = False
        '
        'closeparBtn
        '
        Me.closeparBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.closeparBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.closeparBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.closeparBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.closeparBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.closeparBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.closeparBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeparBtn.Location = New System.Drawing.Point(128, 302)
        Me.closeparBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.closeparBtn.Name = "closeparBtn"
        Me.closeparBtn.Size = New System.Drawing.Size(63, 40)
        Me.closeparBtn.TabIndex = 22
        Me.closeparBtn.Text = ")"
        Me.closeparBtn.UseVisualStyleBackColor = False
        '
        'factBtn
        '
        Me.factBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.factBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.factBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.factBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.factBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.factBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.factBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.factBtn.Location = New System.Drawing.Point(191, 302)
        Me.factBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.factBtn.Name = "factBtn"
        Me.factBtn.Size = New System.Drawing.Size(63, 40)
        Me.factBtn.TabIndex = 21
        Me.factBtn.Text = "n!"
        Me.factBtn.UseVisualStyleBackColor = False
        '
        'divBtn
        '
        Me.divBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.divBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.divBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.divBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.divBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.divBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.divBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.divBtn.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.divBtn.Location = New System.Drawing.Point(254, 302)
        Me.divBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.divBtn.Name = "divBtn"
        Me.divBtn.Size = New System.Drawing.Size(63, 40)
        Me.divBtn.TabIndex = 20
        Me.divBtn.Text = "÷"
        Me.divBtn.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button26.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button26.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button26.Font = New System.Drawing.Font("Open Sans", 10.5!)
        Me.Button26.Location = New System.Drawing.Point(2, 263)
        Me.Button26.Margin = New System.Windows.Forms.Padding(0)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(63, 40)
        Me.Button26.TabIndex = 29
        Me.Button26.Text = "x²"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Button27
        '
        Me.Button27.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button27.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button27.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button27.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.Location = New System.Drawing.Point(65, 263)
        Me.Button27.Margin = New System.Windows.Forms.Padding(0)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(63, 40)
        Me.Button27.TabIndex = 28
        Me.Button27.Text = "1/x"
        Me.Button27.UseVisualStyleBackColor = False
        '
        'absBtn
        '
        Me.absBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.absBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.absBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.absBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.absBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.absBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.absBtn.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.absBtn.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.absBtn.Location = New System.Drawing.Point(128, 263)
        Me.absBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.absBtn.Name = "absBtn"
        Me.absBtn.Size = New System.Drawing.Size(63, 40)
        Me.absBtn.TabIndex = 27
        Me.absBtn.Text = "| x | "
        Me.absBtn.UseVisualStyleBackColor = False
        '
        'expBtn
        '
        Me.expBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.expBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.expBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.expBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.expBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.expBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.expBtn.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.expBtn.Location = New System.Drawing.Point(191, 263)
        Me.expBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.expBtn.Name = "expBtn"
        Me.expBtn.Size = New System.Drawing.Size(63, 40)
        Me.expBtn.TabIndex = 26
        Me.expBtn.Text = "exp"
        Me.expBtn.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button30.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button30.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button30.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button30.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button30.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.Button30.Location = New System.Drawing.Point(254, 263)
        Me.Button30.Margin = New System.Windows.Forms.Padding(0)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(63, 40)
        Me.Button30.TabIndex = 25
        Me.Button30.Text = "mod"
        Me.Button30.UseVisualStyleBackColor = False
        '
        'Button31
        '
        Me.Button31.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button31.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button31.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button31.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button31.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button31.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.Location = New System.Drawing.Point(2, 224)
        Me.Button31.Margin = New System.Windows.Forms.Padding(0)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(63, 40)
        Me.Button31.TabIndex = 34
        Me.Button31.Text = "2nd"
        Me.Button31.UseVisualStyleBackColor = False
        '
        'Button32
        '
        Me.Button32.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button32.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button32.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button32.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button32.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button32.Font = New System.Drawing.Font("Segoe UI", 12.5!)
        Me.Button32.Location = New System.Drawing.Point(65, 224)
        Me.Button32.Margin = New System.Windows.Forms.Padding(0)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(63, 40)
        Me.Button32.TabIndex = 33
        Me.Button32.Text = "π"
        Me.Button32.UseVisualStyleBackColor = False
        '
        'Button33
        '
        Me.Button33.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button33.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button33.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.Button33.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.Button33.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.Button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button33.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.Button33.Location = New System.Drawing.Point(128, 224)
        Me.Button33.Margin = New System.Windows.Forms.Padding(0)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(63, 40)
        Me.Button33.TabIndex = 32
        Me.Button33.Text = "e"
        Me.Button33.UseVisualStyleBackColor = False
        '
        'clearBtn
        '
        Me.clearBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.clearBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.clearBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.clearBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.clearBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.clearBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.clearBtn.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.clearBtn.Location = New System.Drawing.Point(191, 224)
        Me.clearBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.clearBtn.Name = "clearBtn"
        Me.clearBtn.Size = New System.Drawing.Size(63, 40)
        Me.clearBtn.TabIndex = 31
        Me.clearBtn.Text = "C"
        Me.clearBtn.UseVisualStyleBackColor = False
        '
        'delBtn
        '
        Me.delBtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.delBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.delBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.delBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.delBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray
        Me.delBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.delBtn.Font = New System.Drawing.Font("Segoe UI Symbol", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.delBtn.Location = New System.Drawing.Point(254, 224)
        Me.delBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.delBtn.Name = "delBtn"
        Me.delBtn.Size = New System.Drawing.Size(63, 40)
        Me.delBtn.TabIndex = 30
        Me.delBtn.Text = "⌫"
        Me.delBtn.UseVisualStyleBackColor = False
        '
        'Button37
        '
        Me.Button37.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button37.FlatAppearance.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button37.Font = New System.Drawing.Font("Segoe UI Symbol", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button37.Location = New System.Drawing.Point(134, 182)
        Me.Button37.Margin = New System.Windows.Forms.Padding(0)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(108, 41)
        Me.Button37.TabIndex = 36
        Me.Button37.Text = "      Function"
        Me.Button37.UseVisualStyleBackColor = False
        '
        'MC
        '
        Me.MC.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.MC.FlatAppearance.BorderSize = 0
        Me.MC.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control
        Me.MC.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MC.Font = New System.Drawing.Font("Segoe UI", 8.5!, System.Drawing.FontStyle.Bold)
        Me.MC.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.MC.Location = New System.Drawing.Point(1, 149)
        Me.MC.Name = "MC"
        Me.MC.Size = New System.Drawing.Size(51, 36)
        Me.MC.TabIndex = 37
        Me.MC.Text = "MC"
        Me.MC.UseVisualStyleBackColor = False
        '
        'Button39
        '
        Me.Button39.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button39.FlatAppearance.BorderSize = 0
        Me.Button39.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control
        Me.Button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button39.Font = New System.Drawing.Font("Segoe UI", 8.5!, System.Drawing.FontStyle.Bold)
        Me.Button39.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Button39.Location = New System.Drawing.Point(54, 149)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(51, 36)
        Me.Button39.TabIndex = 38
        Me.Button39.Text = "MR"
        Me.Button39.UseVisualStyleBackColor = False
        '
        'Button40
        '
        Me.Button40.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button40.FlatAppearance.BorderSize = 0
        Me.Button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button40.Font = New System.Drawing.Font("Segoe UI", 8.5!, System.Drawing.FontStyle.Bold)
        Me.Button40.Location = New System.Drawing.Point(107, 149)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(51, 36)
        Me.Button40.TabIndex = 39
        Me.Button40.Text = "M+"
        Me.Button40.UseVisualStyleBackColor = False
        '
        'Button41
        '
        Me.Button41.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button41.FlatAppearance.BorderSize = 0
        Me.Button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button41.Font = New System.Drawing.Font("Segoe UI", 8.5!, System.Drawing.FontStyle.Bold)
        Me.Button41.Location = New System.Drawing.Point(160, 149)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(51, 36)
        Me.Button41.TabIndex = 40
        Me.Button41.Text = "M-"
        Me.Button41.UseVisualStyleBackColor = False
        '
        'Button42
        '
        Me.Button42.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button42.FlatAppearance.BorderSize = 0
        Me.Button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button42.Font = New System.Drawing.Font("Segoe UI", 8.5!, System.Drawing.FontStyle.Bold)
        Me.Button42.Location = New System.Drawing.Point(213, 149)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(51, 36)
        Me.Button42.TabIndex = 41
        Me.Button42.Text = "MS"
        Me.Button42.UseVisualStyleBackColor = False
        '
        'Button43
        '
        Me.Button43.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button43.FlatAppearance.BorderSize = 0
        Me.Button43.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Control
        Me.Button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button43.Font = New System.Drawing.Font("Segoe UI", 8.5!, System.Drawing.FontStyle.Bold)
        Me.Button43.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Button43.Location = New System.Drawing.Point(265, 149)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(52, 36)
        Me.Button43.TabIndex = 42
        Me.Button43.Text = "M+"
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Button38
        '
        Me.Button38.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button38.FlatAppearance.BorderSize = 0
        Me.Button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button38.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button38.Location = New System.Drawing.Point(1, 114)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(51, 36)
        Me.Button38.TabIndex = 43
        Me.Button38.Text = "RAD"
        Me.Button38.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button44.FlatAppearance.BorderSize = 0
        Me.Button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button44.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button44.Location = New System.Drawing.Point(54, 114)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(51, 36)
        Me.Button44.TabIndex = 44
        Me.Button44.Text = "F-E"
        Me.Button44.UseVisualStyleBackColor = False
        '
        'txtScreen
        '
        Me.txtScreen.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtScreen.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtScreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtScreen.Location = New System.Drawing.Point(-1, 67)
        Me.txtScreen.Multiline = True
        Me.txtScreen.Name = "txtScreen"
        Me.txtScreen.Size = New System.Drawing.Size(308, 34)
        Me.txtScreen.TabIndex = 45
        Me.txtScreen.Text = "0"
        Me.txtScreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button45
        '
        Me.Button45.FlatAppearance.BorderSize = 0
        Me.Button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button45.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button45.Location = New System.Drawing.Point(-1, -1)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(43, 35)
        Me.Button45.TabIndex = 46
        Me.Button45.Text = "≡"
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Button36.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.Button36.FlatAppearance.BorderSize = 0
        Me.Button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button36.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button36.Location = New System.Drawing.Point(1, 182)
        Me.Button36.Margin = New System.Windows.Forms.Padding(0)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(133, 41)
        Me.Button36.TabIndex = 35
        Me.Button36.Text = "Trigonometry"
        Me.Button36.UseVisualStyleBackColor = False
        '
        'txtScreen2
        '
        Me.txtScreen2.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.txtScreen2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtScreen2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtScreen2.Location = New System.Drawing.Point(1, 45)
        Me.txtScreen2.Name = "txtScreen2"
        Me.txtScreen2.Size = New System.Drawing.Size(306, 19)
        Me.txtScreen2.TabIndex = 47
        Me.txtScreen2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(48, 4)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 25)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "Scientific"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(276, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(43, 35)
        Me.Button1.TabIndex = 50
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Light", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(136, 191)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 25)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "  ƒ "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(319, 501)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtScreen2)
        Me.Controls.Add(Me.Button45)
        Me.Controls.Add(Me.txtScreen)
        Me.Controls.Add(Me.Button44)
        Me.Controls.Add(Me.Button38)
        Me.Controls.Add(Me.Button43)
        Me.Controls.Add(Me.Button42)
        Me.Controls.Add(Me.Button41)
        Me.Controls.Add(Me.Button40)
        Me.Controls.Add(Me.Button39)
        Me.Controls.Add(Me.MC)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.clearBtn)
        Me.Controls.Add(Me.delBtn)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.absBtn)
        Me.Controls.Add(Me.expBtn)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.openparBtn)
        Me.Controls.Add(Me.closeparBtn)
        Me.Controls.Add(Me.factBtn)
        Me.Controls.Add(Me.divBtn)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.sevenBtn)
        Me.Controls.Add(Me.eightBtn)
        Me.Controls.Add(Me.nineBtn)
        Me.Controls.Add(Me.mulBtn)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.fourBtn)
        Me.Controls.Add(Me.fiveBtn)
        Me.Controls.Add(Me.sixBtn)
        Me.Controls.Add(Me.minusBtn)
        Me.Controls.Add(Me.logBtn)
        Me.Controls.Add(Me.oneBtn)
        Me.Controls.Add(Me.twoBtn)
        Me.Controls.Add(Me.threeBtn)
        Me.Controls.Add(Me.plusBtn)
        Me.Controls.Add(Me.lnBtn)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.zeroBtn)
        Me.Controls.Add(Me.dotBtn)
        Me.Controls.Add(Me.equalBtn)
        Me.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents equalBtn As Button
    Friend WithEvents dotBtn As Button
    Friend WithEvents zeroBtn As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents lnBtn As Button
    Friend WithEvents logBtn As Button
    Friend WithEvents oneBtn As Button
    Friend WithEvents twoBtn As Button
    Friend WithEvents threeBtn As Button
    Friend WithEvents plusBtn As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents fourBtn As Button
    Friend WithEvents fiveBtn As Button
    Friend WithEvents sixBtn As Button
    Friend WithEvents minusBtn As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents sevenBtn As Button
    Friend WithEvents eightBtn As Button
    Friend WithEvents nineBtn As Button
    Friend WithEvents mulBtn As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents openparBtn As Button
    Friend WithEvents closeparBtn As Button
    Friend WithEvents factBtn As Button
    Friend WithEvents divBtn As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents absBtn As Button
    Friend WithEvents expBtn As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents clearBtn As Button
    Friend WithEvents delBtn As Button
    Friend WithEvents Button37 As Button
    Friend WithEvents MC As Button
    Friend WithEvents Button39 As Button
    Friend WithEvents Button40 As Button
    Friend WithEvents Button41 As Button
    Friend WithEvents Button42 As Button
    Friend WithEvents Button43 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Button44 As Button
    Friend WithEvents txtScreen As TextBox
    Friend WithEvents Button45 As Button
    Friend WithEvents Button36 As Button
    Friend WithEvents txtScreen2 As TextBox
    Friend WithEvents Label2 As Label
    Public WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
End Class
